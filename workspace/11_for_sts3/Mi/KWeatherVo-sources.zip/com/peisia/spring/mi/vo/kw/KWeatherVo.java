
package com.peisia.spring.mi.vo.kw;

import javax.annotation.Generated;

@Generated("jsonschema2pojo")
public class KWeatherVo {

    public Response response;

}
