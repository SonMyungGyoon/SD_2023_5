
package com.peisia.spring.mi.vo.kw;

import java.util.List;
import javax.annotation.Generated;

@Generated("jsonschema2pojo")
public class Items {

    public List<Item> item;

}
