
package com.peisia.spring.mi.vo.kw;

import javax.annotation.Generated;

@Generated("jsonschema2pojo")
public class Header {

    public String resultCode;
    public String resultMsg;

}
