
package com.peisia.spring.mi.vo.kw;

import javax.annotation.Generated;

@Generated("jsonschema2pojo")
public class Response {

    public Header header;
    public Body body;

}
